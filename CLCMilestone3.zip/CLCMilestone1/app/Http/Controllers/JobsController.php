<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 21th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

// IMPORTANT

namespace App\Http\Controllers;

use App\Job;
use App\User;
use App\Http\Requests\Users\UpdateProfileRequest;
use App\Http\Requests\Jobs\UpdateJobRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class JobsController extends Controller
{
    
    // This method DISPLAYS a page with all the users for the admin
    public function index()
    {
        return view('users.index')->with('users', User::all());       
    }
    
    // To DISPLAY all job posting for and Admin
    public function jobs()
    {
        return view('jobs.index')->with('jobs', Job::all());
    }
    // To DISPLAY all jobs for anyone to see
    public function list()
    {
        return view('jobs.list')->with('jobs', Job::all());
    }
    
    public function show(Job $id)
    {
        return view('jobs.index', ['job'=>id]);
    }
    public function create()
    {
        return view('jobs.create');
    }
    public function store()
    {
        $job = new Job;
        
        $job->jobTitle = request('jobTitle');
        $job->companyName = request('companyName');
        $job->jobLocation = request('jobLocation');
        $job->employmentType = request('employmentType');
        $job->save();
    }
    
    public function edit($id)
    {
        // get the job
        $job = job::find($id);
        
        // show the eidt form and pass the job
        return view('jobs.edit')->with('job', $job);
    }
    
    public function update($id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'jobTitle'       => 'required',
            'companyName'      => 'required|companyName',
            'jobLocation' => 'required|jobLocation',
            'employmentType' => 'required|employmentType'
        );
       /* $validator = Validator::make(Input::all(), $rules);
        
        // process the login
        if ($validator->fails()) {
            return Redirect::to('sharks/' . $id . '/edit')
            ->withErrors($validator)
            ->withInput(Input::except('password'));
        } else {*/
            // store
            $job = job::find($id);
            $job->jobTitle       = Input::get('jobTitle');
            $job->companyName      = Input::get('companyName');
            $job->jobLocation = Input::get('jobLocation');
            $job->employmentType = Input::get('employmentType');
            $job->save();
            
            // redirect
            //Session::flash('message', 'Successfully updated shark!');
            return Redirect::to('jobs.index');
        //}
    }
    
    public function destroy($id)
    {
        // delete
        $job = job::find($id);
        $job->delete();
        
        // Redirect
        //Session::flash('message', 'Successfully deleted the job');
        return Redirect::to('jobs.index');
    }
    
}
