<?php

use App\User;

use App\Job;

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\Hash;

class JobsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    // To automatically insert an admin to the table(use command in terminal)
    public function run()
    {
        $job = Job::where('jobTitle', 'New Job')->first();
        
        if(!$job){
            Job::create([
                'jobTitle'=>'Game Developer',
                'companyName'=>'Nintendo',
                'jobLocation'=>'LA, California',
                'employmentType'=>'Full Time',
           ]);
        }
    }
}
